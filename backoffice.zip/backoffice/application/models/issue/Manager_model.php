<?php

Class Manager_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * Searching Artist information based on request data
     * @param array $request
     * @return array
     */
	function manageIssueSearchInfo( $request, $start=0, $end=1000 ) {
		$respose = array();
		 if(empty($request)){
		 	return $respose;
		 }
		
		 if (!empty($_POST['order'][0])){
		 	$requestOrder = $this->issueOrdering( $_POST['order'][0] );
		 }
		 
		 $issue_title	= (!empty($request['issue_title'])?$request['issue_title']:'');
		 $project_title		= (!empty($request['project_title'])?$request['project_title']:'');
		 $error_code= (!empty($request['error_code'])?$request['error_code']:'');
		 $description=(!empty($request['description'])?$request['description']:'');
		
		  $resolved_by= (!empty($request['resolved_by'])?$request['resovled_by']:'');
		   $solution_by= (!empty($request['solution_by'])?$request['solution_by']:'');
		 $created_by= (!empty($request['created_by'])?$request['created_by']:'');
		 $startDate	= (!empty($request['START_DATE_TIME'])?date(DATE_TIME_FORMAT,strtotime($request['START_DATE_TIME'])):'');
		 $endDate	= (!empty($request['END_DATE_TIME'])?date(DATE_TIME_FORMAT,strtotime($request['END_DATE_TIME'])):'');

		 $this->db->select('*');
		if(!empty( $issue_title )){
			$this->db->where('art.ISSUE_TITLE', $issue_title);
		}
		if (!empty( $project_title)) {
			$this->db->like('art.PROJECT_TITLE', $project_title);
		}
		if(!empty( $error_code )){
			$this->db->like('art.ERROR_CODE', $error_code);
		}
		if(!empty( $description )){
			$this->db->where('art.DESCRIPTION', $description);
		}
		if(!empty( $solution_by )){
			$this->db->like('art.SOLUTION_BY', $solution_by);
		}
		if(!empty( $created_by )){
			$this->db->where('art.CREATED_BY', $created_by);
		}
		if(!empty( $resolved_by )){
			$this->db->where('art.RESOLVED_BY', $resolved_by);
		}
		if(!empty( $startDate )){
			$this->db->where('art.CREATED_DATE >=',$startDate);
		}
		if(!empty( $endDate )){
			$this->db->where('art.CREATED_DATE <=',$endDate);
		}
		if (!empty( $requestOrder )){
			$this->db->order_by( $requestOrder['name'], $requestOrder['order']);
		}
			
		$this->db->limit( $end, $start);
		$query = $this->db->get('issue_tracking as art');
// 		 echo $this->db->last_query();exit;
		return $query->result_array();
	}
	
	function issueOrdering($orderData){
		if (empty($orderData)){
			return array();
		}
		$info = array();
		$info['name']='art.ISSUE_ID';
		if ($orderData['column'] ==0 ){
			$info['name'] = 'art.ISSUE_TITLE';
		}elseif ($orderData['column'] ==1 ){
			$info['name'] = 'art.PROJECT_TITLE';
		}elseif ($orderData['column'] ==2 ){
			$info['name']='art.ERROR_CODE';
		}elseif ($orderData['column'] ==3 ){
			$info['name']='art.DESCRIPTION';
		}elseif ($orderData['column'] ==4 ){
			$info['name']='art.CREATED_BY';
		}elseif ($orderData['column'] ==5 ){
			$info['name']='art.RESOLVED_BY';
		}
		elseif ($orderData['column'] ==6 ){
			$info['name']='art.SOLUTION_BY';
		}
	
		$info['order'] = 'DESC';
		if (!empty($orderData['dir'])){
			$info['order'] = $orderData['dir'];
		}
		return $info;
	}
}

?>
