<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="form-style-2">
   <div class="form-style-2-heading">Issue Management > Update Issue</div>
   <?php
		if(!empty($flash['message'])){
	?>
		<script>
			/*setTimeout(function() {
				$("#error_msg").hide();
			}, 2000);*/
		</script>
		<span id="error_msg" class="<?= $flash['class'] ?>" > 
			<i class="fa fa-info-circle" ></i> <?php echo $flash['message']; ?>
		</span>
<?php }
		if (!empty( $issueData )){
?>
   <form class="innerform" name="regForm" id="regForm" action="<?= base_url().'issue/index/edit/'.$issueData['ISSUE_ID']?>" method="post" enctype="multipart/form-data">
		<label for="field1"><span>Issue Title <span class="required">*</span></span>
      <input type="text" class="input-field" tabindex="2"  id="issue_title" name="issue_title" value="<?= (!empty($issueData['ISSUE_TITLE'])?$issueData['ISSUE_TITLE']:''); ?>"  required/>
      	<label id="issue_title-error" class="error error-msg" for="issue_title" ></label>
      </label>
	  
	  <label for="field1"><span>Project Title <span class="required">*</span></span>
      <input type="text" class="input-field" tabindex="2"  id="project_title" name="project_title" value="<?= (!empty($issueData['PROJECT_TITLE'])?$issueData['PROJECT_TITLE']:''); ?>" required/>
      	<label id="project_title-error" class="error error-msg" for="project_title"></label>
      </label>
	  
	  <label for="field1"><span>Error Code <span class="required">*</span></span>
      <input type="text" class="input-field" tabindex="2"  id="error_code" name="error_code" value="<?= (!empty($issueData['ERROR_CODE'])?$issueData['ERROR_CODE']:''); ?>" required/>
      	<label id="error_code-error" class="error error-msg" for="error_code"></label>
      </label>
	  
	   <label for="field1"><span>Description <span class="required">*</span></span>
	  <textarea rows="4" class="textarea-field" cols="50" tabindex="2"  id="description" name="description" required><?= (!empty($issueData['DESCRIPTION'])?$issueData['DESCRIPTION']:''); ?></textarea>
      	<label id="description-error" class="error error-msg" for="description"></label>
      </label>
	  <label for="field1"><span>Resolved By<span class="required">*</span></span>
      <input type="text" class="input-field" tabindex="2" maxlength="30" id="resolved_by" value="<?= (!empty($issueData['RESOLVED_BY'])?$issueData['RESOLVED_BY']:''); ?>" name="resolved_by" required/>
      	<label id="resolved_by-error" class="error error-msg" for="resolved_by"></label>
      </label>
	  
	  <label for="field1"><span>Created By<span class="required">*</span></span>
      <input type="text" class="input-field" tabindex="2" maxlength="30" id="created_by" value="<?= (!empty($issueData['CREATED_BY'])?$issueData['CREATED_BY']:''); ?>" name="created_by" required/>
      	<label id="created_by-error" class="error error-msg" for="created_by"></label>
      </label>
	  
	  <label for="field1"><span>Solution BY <span class="required">*</span></span>
	  <textarea rows="4" class="textarea-field" cols="50" tabindex="2"  id="solution_by" name="solution_by" required><?= (!empty($issueData['SOLUTION_BY'])?$issueData['SOLUTION_BY']:''); ?></textarea>
      	<label id="solution_by-error" class="error error-msg" for="solution_by"></label>
      </label>
      
      <label><span>&nbsp;</span><input type="submit" value="Update" /></label>
   </form>
   <?php } else { echo '<h3 style="text-align: center">Information Not Found</h3>';}?>
</div>

<script src="<?= base_url().'assets/js/validate/jquery.validate.min.js'?>""></script>   

<script type="text/javascript">
/** menu active script **/
$('#art_manage').addClass('open');
$('#art_manage .submenu').show();
$('#art_manage #view').addClass('submenu-color');


/** remove space input filed rear and end**/
$(function () {
	$('input').blur(function () {                        
		$(this).val(
			$.trim($(this).val())
		);
	});
	$('#description').blur(function () {                        
		$(this).val(
			$.trim($(this).val())
		);
	});
});


$("#issue_title").keypress(function (e) { //letters and digits only allowed
	if (e.which != 8 && e.which != 0 && e.which != 32 && ((e.which < 48) || (e.which > 57)) && ((e.which < 97) || (e.which > 122))) {                 
		return false;             
	}         
});
// Wait for the DOM to be ready
$(function() {
	  // Initialize form validation on the registration form.
	  // It has the name attribute "registration"
	  $("#regForm").validate({
	    // Specify validation rules
	    rules: {
	      // The key name on the left side is the name attribute
	      // of an input field. Validation rules are defined
	      // on the right side
	      issue_title: "required",
	      project_title: { required: true },
	      error_code: { required: true },
	      description: { required: true},
		  solution_by:{required:true},
		  resolved_by: { required:true },
	      created_by: { required: true }
	    },
	    // Specify validation error messages
	    messages: {
	    	issue_title: "Please select issue title",
			project_title: "Please enter project title",
	      error_code:"Please enter error code",
	      description: "Please enter description",
		  solution_by:"please enter solution ",
		  resolved_by: "please enter resolved by",
		  created_by: "Please enter created by"
	    },
	    // Make sure the form is submitted to the destination defined
	    // in the "action" attribute of the form when valid
	    submitHandler: function(form) {
	      form.submit();
	    }
	  });
	});



</script>
