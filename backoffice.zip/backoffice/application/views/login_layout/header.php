<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html >
   <head>
      <meta charset="UTF-8">
      <title>Login Form</title>
      
      <link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css'?>">
	  <!-- jQuery -->
    <script src="<?php echo base_url().'/assets/js/jquery/jquery.min.js'?>"></script>
   </head>
   <body>
       <div class="header">
           
    <div class="logo">
        <p class="logotxt">CONFIGURATION MANAGEMENT DATABASE</p>
<div class="HeaderDisplay">Date: <strong><?PHP echo date("d-m-Y"); ?></strong></div>

           </div>

       </div>
  <input type="hidden" id="baseurl" value="<?= base_url()?>"/>
 <script type="text/javascript">
  var baseurl = $("#baseurl").val();
 </script>