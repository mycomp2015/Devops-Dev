<?php

Class Issue_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

  	public function insert($data){
		if(empty($data)){
			return false;
		}
		
		$result = $this->db->insert('issue_tracking',$data);
		
		return $this->db->insert_id();
	}

	/**
	 * Artist updation
	 * @param array $data
	 * @param integer $id
	 * @return boolean|unknown
	 */
	public function update($data, $id){
		if(empty($data) || empty($id)){
			return false;
		}
		
					$this->db->where('ISSUE_ID', $id);
		$result = $this->db->update('issue_tracking', $data); 
		return $result;
	}
	
	/**
	 * get artist and artist type details
	 * @param string $email
	 * @param string $username
	 * @param string $id
	 * @return array
	 */
	function getIssueDetail( $request ) 
	{
		
		
		$issueId	= (!empty($request['issueId'])?$request['issueId']:'');
$issue_title	= (!empty($request['issue_title'])?$request['issue_title']:'');
		$project_title	= (!empty($request['project_title'])?$request['project_title']:'');
		$error_code	= (!empty($request['error_code'])?$request['error_code']:'');
		$description=(!empty($request['description'])?$request['description']:'');
		
	   $resolved_by	= (!empty($request['resolved_by'])?$request['resolved_by']:'');
	   $solution_by=(!empty($request['solution_by'])?$request['solution_by']:'');
		$created_by	= (!empty($request['created_by'])?$request['created_by']:'');
		 
		$this->db->select('*');
		if(!empty( $issueId )){
			$this->db->where('art.ISSUE_ID', $issueId);
		}
		if(!empty( $issue_title )){
			$this->db->like('art.ISSUE_TITLE', $issue_title);
		}
		if (!empty( $project_title)) {
			$this->db->like('art.PROJECT_TITLE', $project_title);
		}
		if(!empty( $error_code )){
			$this->db->like('art.ERROR_CODE', $error_code);
		}
		if(!empty( $description )){
			$this->db->like('art.DESCRIPTION', $description);
		}
		
		if(!empty( $resolved_by )){
			$this->db->like('art.RESOLVED_BY', $resolved_by);
		}
		
		if(!empty( $created_by )){
			$this->db->where('art.CREATED_BY', $created_by);
		}if(!empty( $solution_by )){
			$this->db->like('art.SOLUTION_BY', $solution_by);
		}
		if(!empty( $startDate )){
			$this->db->where('art.CREATED_DATE >=',$startDate);
		}
		if(!empty( $endDate )){
			$this->db->where('art.CREATED_DATE <=',$endDate);
		}
		
		$query = $this->db->get('issue_tracking as art');
		
		return $query->result_array();
	}
	
	/**
	 * To set update information
	 * Here checking old and new data any changes their add to array
	 * otherwise not added in the array
	 * @param unknown $request
	 * @return array modified info
	 */
	
   
}

?>
