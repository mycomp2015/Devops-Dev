<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<script src = "<?php echo base_url();?>assets/js/datetimepicker_css.js"  type="text/javascript" language="javascript"></script>

<div class="form-style-2">
   <div class="form-style-2-heading">Issue Management >  View</div>
   <form class="innerform" action="" name="searchForm" id="searchForm">

      <label class="searchlabal" for="field1"><span>Issue Title </span><input type="text" class="input-field" name="issue_title" value="" /></label>
      <label class="searchlabal" for="field2"><span>Project Title </span><input type="text" class="input-field" name="project_title" value="" /></label>
     
      <label class="searchlabal" for="field4">
         <span>Error code</span>
         <input type="text" class="input-field" name="error_code" value="" />
      </label>
	  
	  <label class="searchlabal" for="field4">
         <span>Created by</span>
         <input type="text" class="input-field" name="created_by" value="" />
      </label>
	 
	  <label class="searchlabal" for="field4">
         <span>Resolved by</span>
         <input type="text" class="input-field" name="resolved_by" value="" />
      </label>
	  <label class="searchlabal" for="field4">
         <span>Solution by</span>
         <input type="text" class="input-field" name="solution_by" value="" />
      </label>
	  <label class="searchlabal" for="field4">
         <span>Date Range</span>
         <select name="SEARCH_LIMIT" id="SEARCH_LIMIT" class="select-field" onchange="showdaterange(this.value);">
            	<option value="">Select date range</option>
				<option value="1">Today</option>
				<option value="2">Yesterday</option>
				<option value="3">This Week</option>
				<option value="4">Last Week</option>
				<option value="5">This Month</option>
				<option value="6">Last Month</option>
         </select>
      </label>
       <label class="searchlabal" for="field1"><span>Start Date </span>
       <input type="text"  id="START_DATE_TIME" class="input-field" name="START_DATE_TIME" value="<?PHP if(isset($_REQUEST['START_DATE_TIME']))  ?>">
       <!-- <input type="text" class="input-field" id="startdate" name="startdate" value="" />-->
       <a onclick="NewCssCal('START_DATE_TIME','ddmmyyyy','arrow',true,24,false)" href="#"><img src="<?php echo base_url(); ?>assets/images/calendar.png" /></a>
       </label>
      <label class="searchlabal" for="field2"><span>End Date </span>
      <input type="text" id="END_DATE_TIME" class="input-field" name="END_DATE_TIME" value="<?PHP if(isset($_REQUEST['END_DATE_TIME']))  ?>">
      <!-- <input type="text" class="input-field" id="enddate" name="enddate" value="" />-->
      <a onclick="javascript:NewCssCal ('END_DATE_TIME','ddmmyyyy','arrow',true,24,false)" href="#"><img src="<?php echo base_url(); ?>assets/images/calendar.png" /></a>
      </label>
      <p class="submitbtn"><span>&nbsp;</span>


      	<a href="#" class="submit" id="search">Search</a>

          <input class="submit" type="reset" value="Clear" />

       </p>
   </form>
</div>
<div class="table">
<?php //if(!empty($search)){?>
	<table id="example" class="example" cellspacing="1" border="1" width="100%" style="display: none">
	        <thead class="heading-table">
	            <tr>
	                <th>Issue Title</th>
	                <th>Project Title</th>
	                <th>Error Code</th>
	                <th>Description</th>
	                <th>Created by</th>
	                <th>Resolved by</th>

					
					<th>solution by</th>
					<th>Action</th>
					
					
	            </tr>
	        </thead>

          <tbody class="body-table">
         
         </tbody>
	    </table>
      <?php //} else { echo '<h3>No data found</h3>'; } ?> 
</div>	


	<script>

	/** menu active script **/
	$('#art_manage').addClass('open');
	$('#art_manage .submenu').show();
	$('#art_manage #view').addClass('submenu-color');
	

	$('#search').click(function(){	 
	    $('.example').show();
		var str =JSON.stringify($('#searchForm').serializeObject()) ;
		$('.example').DataTable( {
			"order": [[ 0, "asc" ]],
			 "columnDefs": [ {
		          "targets": 7,
		          "orderable": false,
				  
		    } ],
			
			
			destroy: true,
			"searching": false,
			"lengthMenu": [[20], [20]],
	        "processing": true,
	        "serverSide": true,
	        "ajax": $.fn.dataTable.pipeline( {
	            url: baseurl+'issue/index/search',
	            dataType: "json",
	            data: { data: str },
	           // dataSrc: "tableData",
	            pages: 100 // number of pages to cache
	        } )
	    } );
		$(".paginate_button").css("color", "#fff");
	//	alert(str);
	});

	$.fn.serializeObject = function()
	{
	    var o = {};
	    var a = this.serializeArray();
	    $.each(a, function() {
	        if (o[this.name] !== undefined) {
	            if (!o[this.name].push) {
	                o[this.name] = [o[this.name]];
	            }
	            o[this.name].push(this.value || '');
	        } else {
	            o[this.name] = this.value || '';
	        }
	    });
	    return o;
	};
	
	
	function showdaterange(vid)
    {
      if(vid!=''){
          var sdate='';
          var edate='';
          if(vid=="1"){
              sdate='<?php echo date("d-m-Y 00:00:00");?>';
              edate='<?php echo date("d-m-Y 23:59:59");?>';
          }
          if(vid=="2"){
              <?php
              $yesterday=date('d-m-Y',strtotime("-1 days"));?>
              sdate='<?php echo $yesterday." 00:00:00";?>';
              edate='<?php echo $yesterday." 23:59:59";?>';
          }
          if(vid=="3"){
              
            
              <?php
              $sweekday=date("d-m-Y",strtotime(date("d-m-Y"))-((date("w")-1)*24*60*60));
              ?>
              //alert('<?php echo $sweekday;?>');
              sdate='<?php echo $sweekday." 00:00:00";?>';
              edate='<?php echo date("d-m-Y 23:59:59");?>';
          }
          if(vid=="4"){
             <?php
              $sweekday=date("d-m-Y",strtotime(date("d-m-Y"))-((date("w")-1)*24*60*60));
              $slastweekday=date("d-m-Y",strtotime($sweekday)-(7*24*60*60));
              $slastweekeday=date("d-m-Y",strtotime($slastweekday)+(6*24*60*60));
              ?>
              sdate='<?php echo $slastweekday." 00:00:00";?>';
              edate='<?php echo $slastweekeday." 23:59:59";?>';
          }
          if(vid=="5"){
              <?php
              $tmonth=date("m");
              $tyear=date("Y");
              $tdate="01-".$tmonth."-".$tyear;
              $lday=date('t',strtotime(date("d-m-Y")))."-".$tmonth."-".$tyear;
              //$slastweekday=date("d-m-Y",strtotime(date("d-m-Y"))-(7*24*60*60));
              ?>
              sdate='<?php echo $tdate." 00:00:00";?>';
              edate='<?php echo $lday." 23:59:59";?>';
          }
          if(vid=="6"){
              <?php
              $tmonth=date("m");
              $tyear=date("Y");
              $tdate=date("01-m-Y 00:00:00", strtotime("-1 month"));
              $lday=date("t-m-Y 23:59:59", strtotime("-1 month"));
              
              //$slastweekday=date("d-m-Y",strtotime(date("d-m-Y"))-(7*24*60*60));
              ?>
              sdate='<?php echo $tdate;?>';
              edate='<?php echo $lday;?>';
          }
          document.getElementById("START_DATE_TIME").value=sdate;
          document.getElementById("END_DATE_TIME").value=edate;
      }
      
        
    }
	</script>