<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<div class="form-style-2">
   <div class="form-style-2-heading">Dashboard</div>
     <h4 style="text-align: center;margin: 15%;"> Welcome to administrator panel</h4>
</div>

	