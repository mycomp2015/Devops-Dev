<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="form-style-2">
   <div class="form-style-2-heading">Issue Management > View Issue 
	   <?php if (!empty( $issueData['ISSUE_ID'])){?>
	   <a style="float: right; text-decoration: none;" href="<?= base_url().'issue/index/edit_issue/'.$issueData['ISSUE_ID'];?>">Edit</a>
	   <?php } ?>
   </div>
   
<?php 
		if (!empty( $issueData )){//echo '<pre>';print_r($issueData);exit;
?>
	  	<div style="margin: 20px 0px 60px 30px;">
			<label class="informationdiv">
				<span class="textleft">Issue Title</span>
				<span class="textright"><?= (!empty($issueData['ISSUE_TITLE'])?$issueData['ISSUE_TITLE']:'---'); ?></span>
			</label>
		  <label class="informationdiv"><span class="textleft">Project Title </span>
		  	<span class="textright"><?= (!empty($issueData['PROJECT_TITLE'])?$issueData['PROJECT_TITLE']:'---');?></span>
		  </label>
		  <label class="informationdiv"><span class="textleft">Error code </span>
		  	<span class="textright"><?= (!empty($issueData['ERROR_CODE'])?$issueData['ERROR_CODE']:'---');?></span>
		  </label>
	      <p><label class="informationdiv"><span class="textleft">description</span>
	      	<span class="textright"><?= (!empty($issueData['DESCRIPTION'])?$issueData['DESCRIPTION']:'---');?></span></p>
	      </label>
		  <label class="informationdiv"><span class="textleft">Created by </span>
		  	<span class="textright"><?= (!empty($issueData['CREATED_BY'])?$issueData['CREATED_BY']:'---');?></span>
		  	</label>
			
			 <label class="informationdiv"><span class="textleft">Resolved by </span>
		  	<span class="textright"><?= (!empty($issueData['RESOLVED_BY'])?$issueData['RESOLVED_BY']:'---');?></span>
		  	</label>
			<label class="informationdiv"><span class="textleft">Solution  by </span>
		  	<span class="textright"><?= (!empty($issueData['SOLUTION_BY'])?$issueData['SOLUTION_BY']:'---');?></span>
		  	</label>
			 
		 
   </div>
   <?php } else {echo '<h3 style="text-align: center">Information Not Found</h3>';}?>
</div>

<script type="text/javascript">

/** menu active script **/
$('#art_manage').addClass('open');
$('#art_manage .submenu').show();
$('#art_manage #view').addClass('submenu-color');
</script>

