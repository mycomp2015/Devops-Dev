<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
                                          
class Index extends CI_Controller {
 
	function __construct(){	
		parent::__construct();
		$this->load->helper(array('url', 'language'));	
		$this->load->helper('form');
		$this->load->library('session');
		$this->load->model("issue/Issue_model");
		if( !isset($this->session->userdata['ADMIN_ID']) || empty($this->session->userdata['ADMIN_ID'] )){
			redirect(base_url());
		}
	}
 

	function index() {
		
		/** get flash message (error and success)*/
		$this->data['flash'] = $this->session->flashdata('item');
		
		$this->load->view('layout/header');
		$this->load->view('issue/create', $this->data);
		$this->load->view('layout/footer');
	}
	
	/**
	 * Artist view and seach
	 * @author
	 */
	function view() {

		if (!empty($_POST)) {
			$searchData	=	$this->Manager_model->manageIssueSearchInfo( $_POST );

			if(!empty($searchData[0])){
				$this->data['search'] = $searchData;
			}
		}
		$this->load->view('layout/header');
		$this->load->view('issue/view');
		$this->load->view('layout/footer');
	}
	
	public function search(){
		$this->load->model("issue/Manager_model");
		/** set default value in ajax call DataTable boostrap */
		$resultset['recordsTotal'] = 0;
		$resultset['recordsFiltered'] = 0;
		$resultset['data'] = array();
		
		if (!empty($_POST)) {
			/** set limit in ajax call DataTable boostrap */
			$start=0;
			$end=LIMIT_DATATBLE;
			if(isset($_POST['start']) >= $end ){
				$start=$_POST['start'];
			} 
			
			/** get artist searched data */
			$searchData	=	$this->Manager_model->manageIssueSearchInfo( json_decode($_POST['data'],true), $start, $end );
		
			$info = base_url().'issue/index/information/';
			$edit = base_url().'issue/index/edit_issue/';
			
			if(!empty($searchData[0])){
				foreach ( $searchData as $val ){
					$url = '<a href="'.$info.$val['ISSUE_ID'].'" title="view issue info"> <i class="fa fa-list-alt"></i></a>
							<a href="'.$edit.$val['ISSUE_ID'].'" title="edit issue info"> <i class="fa fa-edit"></i></a>';
					
					$data[]=array($val['ISSUE_TITLE'],$val['PROJECT_TITLE'],$val['ERROR_CODE'],$val['DESCRIPTION'],$val['CREATED_BY'],$val['SOLUTION_BY'],$val['RESOLVED_BY'],$url);
				}
				/** set value in ajax call DataTable boostrap */
				$draw = (isset($_POST['draw'])?$_POST['draw']:1);
				$count = count($data);
				$resultset['draw'] = $draw;
				$resultset['recordsTotal'] = $start+$count;
				$resultset['recordsFiltered'] = $start+$count+1;
				$resultset['data'] = $data;
			}
		}
		echo json_encode($resultset);exit;
	}
	
	/**
	 * Artist insert based on inputs
	 * @author
	 */
	function add(){
		$message	=	'Issue creation failed';
		$flag =0;
		if( $this->input->post() ) {
			/** check mandatory fields are avilable or not */ 
			if (!empty($_POST['issue_title']) && !empty($_POST['project_title']) && !empty($_POST['description']) && !empty($_POST['error_code']) && !empty($_POST['created_by'])&& !empty($_POST['solution_by'])&& !empty($_POST['resolved_by'])){
				$issue_title	= $_POST['issue_title'];
				$project_title	= $_POST['project_title'];
				$description	= $_POST['description'];
				$solution_by      = $_POST['solution_by'];
				$error_code	= $_POST['error_code'];
				$created_by	= $_POST['created_by'];
				$resolved_by =$_POST['resolved_by'];
						
				/** set insertion input array **/
				$created		=	date(DATE_TIME_FORMAT);
				$insertUserData =   array(	
											'ISSUE_TITLE'   => $issue_title,
											'PROJECT_TITLE'	=> $project_title,
											'ERROR_CODE'	=> $error_code,
											'DESCRIPTION'	=> $description,
											
											'SOLUTION_BY'   => $solution_by,
											'RESOLVED_BY'   => $resolved_by,
											'CREATED_BY' 	=> $created_by,
											'CREATED_DATE' 	=> $created
									);
				/** insert given input array */
				$insertUserId	    =   $this->Issue_model->insert($insertUserData);
				if(!empty( $insertUserId )){
					$flashClass = 'success';
					$message	=	'Issue creation Success';
				}
						
			}
		}
		
		
		
// 		$this->session->set_flashdata('message', $message);
		$this->session->set_flashdata('item', array('message' => $message,'class' => $flashClass));
		redirect(base_url() . 'issue/index');
	}
	
	
	
	/**
	 * Edit view page
	 * Showing Artist information based on artistID
	 * @param unknown $artistId
	 * @author
	 */
	public function edit_issue( $issueId ){
		/** get flash message (error and success)*/
		$this->data['flash'] = $this->session->flashdata('item');
		

		/** get issue details based on issueId */
		$data['issueId']=$issueId;
		$issueDetails	=	$this->Issue_model->getIssueDetail( $data );
		if (!empty( $issueDetails[0])){
			$this->data['issueData'] = $issueDetails[0];
		}
		
		$this->load->view('layout/header');
		$this->load->view('issue/edit',$this->data);
		$this->load->view('layout/footer');
	}
	
	/**
	 * Update artist Information based on artistId and Post value
	 * @param unknown $artistId
	 * @author
	 * @return sucess and failure message
	 */
	public function edit( $issueId ){
		$class= $this->router->fetch_class().'/'.$this->router->fetch_method();
		$this->data = '';
		$flag =0;
		$data['issueId']=$issueId;
		$issueDetails	=	$this->Issue_model->getIssueDetail( $data );
		if (empty( $issueDetails[0])){
			$this->session->set_flashdata('message', 'Invalid album information');
			redirect(base_url() . 'issue/index/view'); 
		}
		
		$message =	'Update failed please try again';
		if( $this->input->post() ) {
			/** check mandatory fields are avilable or not */ 
			if (!empty($_POST['issue_title']) && !empty($_POST['project_title']) && !empty($_POST['description']) && !empty($_POST['error_code']) && !empty($_POST['created_by'])&& !empty($_POST['resolved_by']) && !empty($_POST['solution_by'])){
				$issue_title	= $_POST['issue_title'];
				$project_title	= $_POST['project_title'];
				$description	= $_POST['description'];
				$error_code	= $_POST['error_code'];
				
				$resolved_by =$_POST['resolved_by'];
				$created_by	= $_POST['created_by'];
				$solution_by =$_POST['solution_by'];
						
				/** set insertion input array **/
				$created		=	date(DATE_TIME_FORMAT);
				$insertUserData =   array(	
											'ISSUE_TITLE'   => $issue_title,
											'PROJECT_TITLE'	=> $project_title,
											'ERROR_CODE'	=> $error_code,
											'DESCRIPTION'	=> $description,
											'RESOLVED_BY'   => $resolved_by,
											'SOLUTION_BY'   => $solution_by,
											'CREATED_BY' 	=> $created_by
									);
				/** insert given input array */
				$insertUserId	    =   $this->Issue_model->update($insertUserData, $issueId);
				if(!empty( $insertUserId )){
					$flashClass = 'success';
					$message	=	'Issue Updated Success';
				}
						
			}
		}
		
		
// 		$this->session->set_flashdata('message', $message);
		$this->session->set_flashdata('item', array('message' => $message,'class' => $flashClass));
		redirect(base_url() . 'issue/index/edit_issue/'.$issueId);
	}
	
	/**
	 * Artist information view page
	 * artistId based on information viewed
	 * @param unknown $artistId
	 */
	public function information( $issueId ){
		/** checking input empty or not if empty then redirect view page**/
		if (empty($issueId)){
			redirect(base_url().'issue/index/view');
		}
		
		$this->data ='';
		
	
		/** get issue details based on issueId */
		$data['issueId']=$issueId;
		$issueDetails	=	$this->Issue_model->getIssueDetail( $data );
		if (!empty( $issueDetails[0])){
			$this->data['issueData'] = $issueDetails[0];
		}
	
		$this->load->view('layout/header');
		$this->load->view('issue/info',$this->data);
		$this->load->view('layout/footer');
	}
 
}
 
?>