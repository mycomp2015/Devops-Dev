<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html >
   <head>
      <meta charset="UTF-8">
      <title>CONFIGURATION MANAGEMENT DATABASE</title>
      
  <link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="<?= base_url().'assets/css/style.css'?>">
      <link rel='stylesheet prefetch' href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
      <script src="<?= base_url().'assets/js/jquery/jquery.min.js'?>"></script>
	<script src ="<?= base_url().'assets/js/jquery.dataTables.min.js'?>"  type="text/javascript"></script>
    <script src="<?= base_url().'assets/js/index.js'?>"></script>
   </head>
   <body>
       <div class="header">
           
    <div class="logo">

     
        <p class="logotxt">CONFIGURATION MANAGEMENT DATABASE</p>
    

           </div>
       </div>
    
<div class="sidebarmenu">
       <div class="form-style-2-heading">Main Menu</div>
     <ul id="accordion" class="accordion">
   
  
  <li class="parentli" id="art_manage">
    <div class="link">Manage Bugs<i class="fa fa-chevron-down"></i></div>
    <ul class="submenu">
      <li id="create"><a href="<?= base_url().'issue/index'?>">Create Bug</a></li>
      <li id="view"><a href="<?= base_url().'issue/index/view'?>">View Bug</a></li>
    </ul>
  </li>
  
  <li class="parentli" id="logout">
    <a href="<?= base_url().'logout'?>" style="text-decoration: none;"><div class="link"><i class="fa fa-sign-out"></i>Logout</div></a>
  </li>
</ul>
 
       </div>
 <input type="hidden" id="baseurl" value="<?= base_url()?>"/>
 <script type="text/javascript">
  var baseurl = $("#baseurl").val();
 var global_baseurl = $("#baseurl").val();

 </script>
     