<?php

Class Manager_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /** 
     * get count artist,song,album and user
     * @return array
     */
	function manageDashboardInfo(  ) {
		$this->db->select('count(*) as ALBUM_COUNT');
		$query = $this->db->get('albums');
		$result['album']=  $query->row_array();
		
		$this->db->select('count(*) as ARTIST_COUNT');
		$query = $this->db->get('artists');
		$result['artist']=  $query->row_array();
		
		$this->db->select('count(*) as SONGS_COUNT');
		$query = $this->db->get('songs');
		$result['songs']=  $query->row_array();
		
		$this->db->select('count(*) as USER_COUNT');
		$query = $this->db->get('users');
		$result['user']=  $query->row_array();
		
		return $result;
	}
	
	/**
	 * Searching song information based on request data
	 * @param array $request
	 * @return array
	 */
	function manageSongInfo( ) {
		$respose = array();

		$this->db->select('song.SONG_ID,song.SONG_ALBUM_ID,song.SONG_NAME,song.SONG_AMOUNT,song.SONG_COMPANY_PERCENTAGE,song.SONG_COVER_IMAGE,song.SONG_GENRES_ID,song.SONG_MOOD_ID')
					->select('song.SONG_LOCATION, song.SONG_CITY, song.SONG_COUNTRY, song.SONG_LISTENED_COUNT, song.SONG_FOLLOWER_COUNT, song.SONG_IS_PODCAST, song.SONG_PODCAST_CATEGORY, song.SONG_STATUS')
					->select('album.ALBUM_NAME, gen.GENRES_NAME, mood.MOOD_NAME, art.ARTISTS_USERNAME')
					->join('albums as album','album.ALBUM_ID=song.SONG_ALBUM_ID','left')
					->join('artists as art','album.ALBUM_ARTISTS_ID=art.ARTISTS_ID','left')
					->join('genres_types as gen','gen.GENRES_ID=song.SONG_GENRES_ID','left')
					->join('mood_types as mood','mood.MOOD_ID=song.SONG_MOOD_ID','left');
	
	
		$this->db->limit( 1000 );
		$query = $this->db->get('songs As song');
	
		// echo $this->db->last_query();exit;
		return $query->result_array();
	}
}

?>
